package com.springbootdemo.springbootdemo;

import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
@SpringBootApplication(scanBasePackages ="com.springbootdemo.studentcontroller")
@EntityScan(basePackages="com.springbootdemo.dto")
@EnableJpaRepositories(basePackages="com.springbootdemo.studentrepository")

public class SpringbootdemoApplication 
{

	public static void main(String[] args)
	{
		SpringApplication.run(SpringbootdemoApplication.class, args);
	}

}
