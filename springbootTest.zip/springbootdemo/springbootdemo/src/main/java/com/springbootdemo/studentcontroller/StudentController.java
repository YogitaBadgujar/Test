package com.springbootdemo.studentcontroller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.springbootdemo.dto.Student;
import com.springbootdemo.studentrepository.StudentRepository;

@RestController

public class StudentController 
{
	 private StudentRepository sr;

	@Autowired
	    public StudentController(StudentRepository sr)
	    {
	        this.sr = sr;
	    }
   
   @PostMapping("/rohini")
   public Student save(@RequestBody Student s)
   {
	   System.out.println("Student Data Saved Successfully");
	   
	   return sr.save(s);
	   
   }
   
   @PutMapping("/U")
   public Student update(@RequestBody Student s)
   {
	   System.out.println("Data updated succefully");
	   return sr.save(s);  
   }
   
   @GetMapping("/F")
	public Student fetchData(@RequestParam int id)
	{
		sr.findById(id);
		Optional<Student> op=sr.findById(id);
		Student s=op.get();
		return s; 
    }
   
   @GetMapping("/fN")
   public List<Student> fetchByName(@RequestParam String name)
   {
 	  
 	  List<Student>s=sr.findByName(name);
 	 
 	  return s;
   }
   
   @DeleteMapping("/d")
   public String deleteById(@RequestParam int id)
   {
 	  sr.deleteById(id);
 	  return "Data deleted Successfully";
   }

}






